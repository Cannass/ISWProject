import re

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.forms import forms
from django import forms
from django.contrib.auth.models import User
from Crypto_ISW.models import CriptoValuta, Disponibilita, Wallet, TassoDiCambio,Transazione,Valuta


'''
Form per la registrazione dell'utente
- integrato controllo che la password inserita e la sua conferma combacino
- integrato controllo per verificare che l'username non contenga caratteri speciali e che non sia gia' esistente
- integrato controllo che verifichi che la mail inserita sia valida
'''
class RegistrationForm(forms.Form):
    username = forms.CharField(label='Username', max_length=30, widget=forms.TextInput(attrs={'class': 'mdl-textfield__input'}))
    email = forms.EmailField(label='Email', error_messages={'invalid': "Email non valida."}, widget=forms.TextInput(attrs={'class': 'mdl-textfield__input'}))
    password1 = forms.CharField(min_length=8, label='Password',
                                widget=forms.PasswordInput(attrs={'class': 'mdl-textfield__input'}))
    password2 = forms.CharField(min_length=8, label='Password (Conferma)',
                                widget=forms.PasswordInput(attrs={'class': 'mdl-textfield__input'}))

    def clean_password2(self):
        if 'password1' in self.cleaned_data:
            password1 = self.cleaned_data['password1']
            password2 = self.cleaned_data['password2']
            if password1 == password2:
                return password2
        raise forms.ValidationError('Le password inserite sono diverse.')

    def clean_username(self):
        if 'username' in self.cleaned_data:
            username = self.data['username']
            if re.search(r'^\w+$', username): #Verifica presenza caratteri speciali
                    presenzaUtente = User.objects.filter(username=username).count() #Verifica presenza utenti con stesso username
                    if presenzaUtente == 0:
                        return username
                    else:
                        raise forms.ValidationError('Username gia esistente.')
        raise forms.ValidationError('L username puo contenere solo caratteri alfanumerici e underscore')

    def clean_email(self):
        email = self.cleaned_data['email']
        try:
            validate_email(email) #funzione di Django che verifica la validita' della mail inserita
            return email
        except ValidationError:
            raise forms.ValidationError('Email non valida.')


'''
Form per effettuare il login
'''
class LoginForm(forms.Form):
    username = forms.CharField(label='Username', max_length=30, widget=forms.TextInput(attrs={'class': 'mdl-textfield__input'}))
    password = forms.CharField(label='Password',
                          widget=forms.PasswordInput(attrs={'class': 'mdl-textfield__input'}))

'''
Form per l'inserimento della disponibilita di criptovaluta
'''
class AggiuntaCriptoValutaForm(forms.Form):
        listaCriptoValute = []
        for tmp in CriptoValuta.objects.all():
            listaCriptoValute.append((tmp.codice, tmp.codice + " - " +tmp.nome))  #Lista da visualizzare nella drop down list per la selezione della CriptoValuta

        selezioneCriptoValute = forms.ChoiceField(label="Seleziona Cripto Valuta Da Aggiungere", required=False,
                                                  widget=forms.Select(attrs={'class': 'mdl-selectfield__select'}), choices=listaCriptoValute)
        quantita = forms.FloatField(label="Quantita'",required=True, widget=forms.NumberInput(attrs={'class': 'mdl-textfield__input'}),min_value=0.001)


'''
Form per l'invio di una transazione 
- Parametro in ingresso: utente sessione
- Generate lista delle disponibilita utente, e lista wallet a cui inviare la transazione
- Queste liste verranno usate per popolare i vari cambi
'''
class AggiuntiTransazioneForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        form = super(AggiuntiTransazioneForm, self).__init__(*args, **kwargs)
        walletUtente = Wallet.objects.get(proprietario=self.user)

        listaWalletUtente = []
        for tmp in User.objects.all():
            if tmp.id != self.user.id:
                listaWalletUtente.append((tmp.id, tmp.username))

        listaDisponibilita = []
        for tmp in Disponibilita.objects.filter(wallet=walletUtente):
            listaDisponibilita.append((tmp.criptovaluta.codice, tmp.criptovaluta.nome + "---Disponibili: " + str(tmp.valore)))

        self.fields['selezionawallet'] = forms.ChoiceField(label="Seleziona Wallet Destinatario", required=True,
                                                           widget=forms.Select(attrs={'class': 'mdl-selectfield__select'}),
                                                           choices=listaWalletUtente)
        self.fields['criptovaluta'] = forms.ChoiceField(label="Seleziona La criptovaluta", required=True,
                                                        widget=forms.Select(attrs={'class': 'mdl-selectfield__select'}), choices=listaDisponibilita)

        self.fields['quantita'] = forms.FloatField(label="quantita", required=True, min_value=0.001,
                                                   widget=forms.NumberInput(attrs={'class': 'mdl-textfield__input'}))




'''
Form per la modifica di un tasso di cambio
- Parametro in ingresso: utente sessione
- Generata lista dei tassi di cambio dell utente, verra' usata per popolare il form selezione tasso
'''
class ModificaTassoCambioForm(forms.Form):
    def __init__(self, *args, **kwargs):

        self.user = kwargs.pop('user')
        form = super(ModificaTassoCambioForm, self).__init__(*args, **kwargs)

        walletUtente = Wallet.objects.get(proprietario=self.user)
        tassiUtente = TassoDiCambio.objects.filter(walletUtente=walletUtente).order_by('criptovaluta')

        listaTassiCambio = []
        for tmpTasso in tassiUtente:
            listaTassiCambio.append(
                (tmpTasso.id, tmpTasso.criptovaluta.nome + " - " + tmpTasso.valuta.nome))

        self.fields['selezioneTasso'] = forms.ChoiceField(label="Seleziona il Tasso di Cambio da modificare", widget=forms.Select(attrs={'onchange': 'cambiaInputValore();', 'class': 'mdl-selectfield__select'}),
                                                          choices=listaTassiCambio, required=True)

        self.fields['inputValoreTasso'] = forms.FloatField(label="Valore Tasso", min_value=0.001, widget=forms.NumberInput(attrs={'class': 'mdl-textfield__input'}), required=True, initial=None)
