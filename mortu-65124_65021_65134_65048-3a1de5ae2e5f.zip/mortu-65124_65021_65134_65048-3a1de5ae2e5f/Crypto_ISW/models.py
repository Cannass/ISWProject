# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator



'''
Classe per gestire il wallet dell'utente possiede una chiave esterna al proprietario del wallet
'''
class Wallet(models.Model):
    proprietario = models.ForeignKey(User, on_delete=models.CASCADE)
    valutaselezionata = models.ForeignKey('Valuta', on_delete=models.CASCADE)


'''
Classe per gestire le cryptoValute, con un nome e un'abbreviazione della cryptovaluta
'''
class CriptoValuta(models.Model):
    nome = models.CharField(max_length=10)
    codice = models.CharField(max_length=5)

'''
Classe per gestire la quantita di una cryptovaluta all'interno del wallet, possiede una chiave esterna al wallet e alla cryptovaluta
'''
class Disponibilita(models.Model):
    valore = models.FloatField()
    wallet = models.ForeignKey(Wallet, on_delete=models.CASCADE)
    criptovaluta = models.ForeignKey(CriptoValuta, on_delete=models.CASCADE)

'''
Classe per gestire lo scambio di cryptovalute tra utenti,
possiede due chiavi esterni a wallet per mittente e destinatario
e una a cryptovaluta per sapere quale crypto valuta venga scambiata
'''
class Transazione(models.Model):
    alphanumeric = RegexValidator(r'^[0-9a-zA-Z]*$', 'Only alphanumeric characters are allowed.')
    data = models.DateField()
    idtransazione = models.CharField(max_length=32, validators=[alphanumeric])
    quantita = models.FloatField()
    mittente = models.ForeignKey(Wallet, related_name='mittente', on_delete=models.CASCADE)
    destinatario = models.ForeignKey(Wallet, related_name='destinatario', on_delete=models.CASCADE)
    cripto = models.ForeignKey(CriptoValuta, on_delete=models.CASCADE)

'''
Classe per gestire le valute, possiede il nome della valuta e il relativo simbolo
'''
class Valuta(models.Model):
    nome = models.CharField(max_length=10)
    simbolo  = models.CharField(max_length=1)

'''
Classe per gestire il tasso di cambio tra cryptovaluta e valuta, con riferimento
alla valuta, criptovaluta e wallet del tasso di cambio. A questi si aggiunge il valore del tasso
di cambio float
'''
class TassoDiCambio(models.Model):
    tasso = models.FloatField(default=1)
    valuta = models.ForeignKey(Valuta, on_delete=models.CASCADE)
    criptovaluta = models.ForeignKey(CriptoValuta, on_delete=models.CASCADE)
    walletUtente = models.ForeignKey(Wallet, on_delete=models.CASCADE)