# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from django.contrib import messages
from django.db.models import Q
from django.forms import forms
from django.shortcuts import render, get_object_or_404, render_to_response, redirect
from django.contrib.auth import authenticate, logout, login
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.utils.crypto import get_random_string
from Crypto_ISW.form import RegistrationForm, LoginForm, AggiuntaCriptoValutaForm, ModificaTassoCambioForm
from Crypto_ISW.form import AggiuntiTransazioneForm
from .models import User, CriptoValuta, Wallet, Disponibilita, Valuta, TassoDiCambio,Transazione
from datetime import datetime

'''
Definizione della funzione di reindirizzamento:
se dato url vuoto reindirizza alla pagina di login
'''
def EmptyUrl(request):
    return HttpResponseRedirect('/login')


'''
Definizione della funzione di Login
- Controllo che l'utente non sia gia' loggato con la funzione .is_anonymous()
- Altrimenti reindirizzo l'utente alla home
- Verifico che che il la tipologia di richiesta sia POST
- Utilizzo il metodo authenticate per capire dal sistema se l'account esista e che sia attivo
- Nel caso non esista e sia attivo eseguo il login attraverso il metodo login
- Altrimenti mostro un errore
'''
def Login(request):
    userid = request.user
    if userid.is_anonymous():
         logout(request)
         next = request.POST.get('next', '/home/')
         errormsg = request.POST.get('errormsg')
         if request.method == "POST":
             form = LoginForm(request.POST)

             if form.is_valid():
                 user = authenticate(username=form.cleaned_data['username'], password=form.cleaned_data['password'])
                 if user is not None:
                     if user.is_active:
                         login(request, user)
                         return HttpResponseRedirect(next,user)
                     else:
                         return HttpResponse("Account non attivo")
                 else:
                     messages.warning(request, 'I dati inseriti non sono validi')

                     return render(request, 'login.html', {'form': form, 'next': next})
         form = LoginForm()
         return render(request, 'login.html', {'form': form, 'next': next})
    else:
        return HttpResponseRedirect('/home')


'''
Definizione della funzione Home
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Ottengo dal database la lista delle disponibilita' e la valuta preferita per effettuare la conversione nella HomePage
- Nel caso non ci siano Disponibilita' mostro un messaggio
'''
def Home(request):
    userid = request.user

    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=userid)
        try:
            valselezionata = walletUtente.valutaselezionata
        except TassoDiCambio.DoesNotExist:
            valselezionata = None
        try:
            disponibilitaSelezionataUtente = Disponibilita.objects.filter(wallet=walletUtente)
            cont = 0
            for x in disponibilitaSelezionataUtente:

                supporto = TassoDiCambio.objects.get(criptovaluta = x.criptovaluta,valuta= valselezionata,walletUtente=walletUtente)
                cont = cont + x.valore * supporto.tasso
            cont = str(cont)+" "+valselezionata.simbolo
            listaDisponibilitaUtente = Disponibilita.objects.filter(wallet=walletUtente)

        except Disponibilita.DoesNotExist:
            listaDisponibilitaUtente = None
            cont = None
            return render(request, 'home.html', {'listaDisponibilitaUtente': listaDisponibilitaUtente,
                                                 'disponibilitaSelezionataUtente': cont})

        return render(request, 'home.html', {'listaDisponibilitaUtente': listaDisponibilitaUtente, 'disponibilitaSelezionataUtente': cont})
    else:
        return HttpResponseRedirect('/login')


'''
Definizione della funzione per aggiungere una nuova transazione
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Attraverso il form ottengo il riferimento al wallet destinatario, la criptovaluta e la quantita' da trasferire
- Verifico che la quantita' da trasferire non sia superiore alle disponibilita' di quella criptovaluta
- Se e' superiore reindirizzo alla stessa pagina senza effettuare nessuna operazione
- Altrimenti rimuovo la quantita' di criptovaluta dal wallet del mittente e la aggiungo a quello del destinatario
'''
def AggiungiTransazione(request):

    userid = request.user
    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=request.user)

        if request.method == 'POST':

            form = AggiuntiTransazioneForm(user = userid)
            destinatario = request.POST.get('selezionawallet')
            quantita = request.POST.get('quantita')
            criptovaluta = request.POST.get('criptovaluta')
            disponibilitaPresente = Disponibilita.objects.get(criptovaluta__codice=criptovaluta, wallet=walletUtente)
            cripto = CriptoValuta.objects.get(codice=criptovaluta)
            supporto = disponibilitaPresente.valore
            soldiresidui = supporto -float(quantita)

            if float(quantita) <= float(disponibilitaPresente.valore):
                    if soldiresidui >= 0:
                        disponibilitaPresente.valore = disponibilitaPresente.valore - float(quantita)

                        walletDestinatario = Wallet.objects.get(proprietario__id=destinatario)

                        try:
                            disponibilitaDestinatario = Disponibilita.objects.get(criptovaluta__codice=criptovaluta,
                                                                                  wallet__proprietario=destinatario)


                            if soldiresidui == 0:
                                Disponibilita.objects.filter(criptovaluta__codice=criptovaluta,wallet=walletUtente).delete()

                            else:
                                disponibilitaPresente.valore = soldiresidui
                                disponibilitaPresente.save()

                            disponibilitaDestinatario.valore = float(disponibilitaDestinatario.valore) + float(quantita)
                            disponibilitaDestinatario.save()

                        except Disponibilita.DoesNotExist:

                           if soldiresidui == 0:
                               Disponibilita.objects.filter(criptovaluta__codice=criptovaluta, wallet=walletUtente).delete()
                           else:
                               disponibilitaPresente.valore = soldiresidui
                               disponibilitaPresente.save()
                           cripto= CriptoValuta.objects.get(codice=criptovaluta)
                           Disponibilita.objects.create(valore=quantita, wallet=walletDestinatario,criptovaluta=cripto)


                    controllo = True
                    #cicla finche' non trova un codice da 32 caratteri non esistente
                    while controllo:
                        transazioneid = get_random_string(length=32) #Ottengo un id alfanumerico di 32 caratteri
                        tmp = Transazione.objects.filter(idtransazione=transazioneid).count()
                        if tmp == 0:
                            controllo = False
                        else:
                            controllo = True
                    Transazione.objects.create(idtransazione = transazioneid, mittente=walletUtente,destinatario=walletDestinatario,quantita=quantita,cripto=cripto,data=datetime.now())

                    form = AggiuntiTransazioneForm(user=userid)
                    listaTransazioniEffettuate = Transazione.objects.filter(mittente=walletUtente)
                    listaTransazioniEffettuate.order_by('data')
                    listaTransazioniRicevute = Transazione.objects.filter(destinatario=walletUtente)
                    listaTransazioniRicevute.order_by('data')
                    return render(request, 'transazioni.html', {'form': form,'listaTransazioniEffettuate': listaTransazioniEffettuate,
                                                                'listaTransazioniRicevute': listaTransazioniRicevute,})
            else:
                listaTransazioniEffettuate = Transazione.objects.filter(mittente=walletUtente)
                listaTransazioniEffettuate.order_by('data')
                listaTransazioniRicevute = Transazione.objects.filter(destinatario=walletUtente)
                listaTransazioniRicevute.order_by('data')
                return render(request, 'transazioni.html', {'form': form, 'listaTransazioniEffettuate': listaTransazioniEffettuate, 'listaTransazioniRicevute': listaTransazioniRicevute,
                                                            'error': 'Importo inserito superiore alla disponibilità corrente'})

        listaTransazioniEffettuate = Transazione.objects.filter(mittente=walletUtente)
        listaTransazioniEffettuate.order_by('data')
        listaTransazioniRicevute = Transazione.objects.filter(destinatario=walletUtente)
        listaTransazioniRicevute.order_by('data')
        form = AggiuntiTransazioneForm(user=userid)
        return render(request, 'transazioni.html', {'form': form, 'listaTransazioniEffettuate': listaTransazioniEffettuate, 'listaTransazioniRicevute': listaTransazioniRicevute})
    else:
        return HttpResponseRedirect('/login')


'''
Definizione della funzione che permette la visualizzazione dei dettagli di una transazione gia' eseguita
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Tramite la GET ottengo l'ID della transazione da visualizzare
- Controllo che l'utente intezionato a visualizzare la transazione sia o il mittente o il destinatario della stessa
- Nel caso non lo sia reindirizzo alla pagina transazioni dove potra' visualizzare le proprie transazioni
'''
def DettaglioTransazione(request):
    userid = request.user
    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=request.user)
        listaTransazioni = Transazione.objects.filter(Q(mittente=walletUtente) |
                                                      Q(destinatario=walletUtente))
        listaTransazioni.order_by('data')
        form = AggiuntiTransazioneForm(user=userid)
        if request.method == 'GET':
            idTransazione = request.GET.get('id')
            if Transazione.objects.filter(id=idTransazione).count() > 0:
                transazioneScelta = Transazione.objects.get(id=idTransazione)
                if (transazioneScelta.mittente_id == walletUtente.id) or (transazioneScelta.destinatario_id == walletUtente.id):
                    return render(request, 'dettagliotransazione.html', {'transazioneScelta': transazioneScelta})
                else:
                    return render(request, 'transazioni.html', {'form': form, 'listaTransazioni': listaTransazioni})
            else:
                return render(request, 'transazioni.html', {'form': form, 'listaTransazioni': listaTransazioni})
        HttpResponseRedirect('/transazioni/')
    else:
        return HttpResponseRedirect('/login')


'''
Definizione della funzione che permette l'inserimento di nuovi fondi di Criptovalute nel Wallet Utente
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Tramite il form ottengo il codice della criptovaluta da inserire e la quantita' della stessa
- Verifico che la quantita' sia maggiore di 0, altrimenti mostro un errore
- Se lo è verifico se nel Wallet Utente è gia' presente quella Criptovaluta o no
- Se non lo è creo una nuova istanza per quella Criptovaluta
- Altrimenti aggiungo la quantita' desiderata a quella gia' presente
'''
def ModificaCriptoValuta(request):
    userid=request.user
    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=request.user)
        if request.method == 'POST':
            criptovalutaCOD = request.POST.get('selezioneCriptoValute')
            criptovalutaScelta = CriptoValuta.objects.get(codice=criptovalutaCOD)
            quantita = request.POST.get('quantita')
            if quantita > 0:

                checkDisponibilitaCriptovaluta = Disponibilita.objects.filter(criptovaluta__codice=criptovalutaCOD,
                                                                              wallet=walletUtente).count()
                if checkDisponibilitaCriptovaluta==0:
                    Disponibilita.objects.create(valore=quantita, wallet=walletUtente, criptovaluta=criptovalutaScelta)
                else:
                    disponibilitaPresente = Disponibilita.objects.get(criptovaluta__codice=criptovalutaCOD, wallet=walletUtente)
                    disponibilitaPresente.valore = disponibilitaPresente.valore + float(quantita)
                    disponibilitaPresente.save()

                listaDisponibilita = []
                for tmp in Disponibilita.objects.filter(wallet=walletUtente):
                    listaDisponibilita.append(tmp)

                form = AggiuntaCriptoValutaForm()
                listaDisponibilita = Disponibilita.objects.filter(wallet=walletUtente)
                return render(request, 'modificacriptovalute.html', {'listaDisponibilita': listaDisponibilita, 'form': form, 'listaRimozione': listaDisponibilita})
            else:
                raise forms.ValidationError('Il valore deve essere superiore o uguale a 0,001.')
        listaDisponibilita = []
        for tmp in Disponibilita.objects.filter(wallet=walletUtente):
            listaDisponibilita.append(tmp)
        form = AggiuntaCriptoValutaForm()
        listaDisponibilita = Disponibilita.objects.filter(wallet=walletUtente)
        return render(request, 'modificacriptovalute.html', {'listaDisponibilita': listaDisponibilita, 'form': form, 'listaRimozione': listaDisponibilita})
    else:
        return HttpResponseRedirect('/login')

'''
Definizione della funzione che permette la rimozione di Criptovalute dal Wallet Utente
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Tramite il form ottengo l'id dell'istanza della Criptovaluta nel Wallet e la elimino
- Infine reindirizzo alla stessa pagina per aggiornarne il contenuto
'''
def RimuoviCriptoValuta(request):
    userid = request.user
    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=request.user)
        if request.method == 'POST':
            disponibilitaCOD = request.POST.get('eliminaDisponibilitaCriptovaluta')
            disponibilitaScelta = Disponibilita.objects.get(id=disponibilitaCOD)
            Disponibilita.objects.filter(criptovaluta=disponibilitaScelta.criptovaluta).delete() #eliminazione

        return HttpResponseRedirect('/modificacriptovalute')
    else:
        return HttpResponseRedirect('/login')

'''
Definizione della funzione che permette la visualizzazione della pagina Tassi di cambio e dei relativi contenuti
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
'''
def TassiCambio(request):
    userid = request.user
    if not userid.is_anonymous():
        walletUtente = Wallet.objects.get(proprietario=request.user)
        valutaSelezionatoUtente = walletUtente.valutaselezionata

        listaValuteDisponibili = Valuta.objects.all()
        formModificaTasso = ModificaTassoCambioForm(user=request.user)
        listaTassiCambio = TassoDiCambio.objects.filter(walletUtente=walletUtente)
        listaCriptovaluteDisponibiili = CriptoValuta.objects.all()

        return render(request, 'tassicambio.html', {'listaValuteDisponibili':listaValuteDisponibili,'listaCriptovaluteDisponibili':listaCriptovaluteDisponibiili,
                                                    'valutaSelezionata':valutaSelezionatoUtente,'formModificaTasso': formModificaTasso,'listaTassiCambio':listaTassiCambio})
    else:
        return HttpResponseRedirect('/login')

'''
Definizione della funzione che permette la modifica di un tasso di cambio tra una CriptoValuta ed una Valuta
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Attraverso il form ottengo il tasso che si vuole modificare ed il nuovo tasso di cambio da inserire
- Una volta modificato reindirizzo alla stessa pagina per aggiornarne il contenuto
'''
def TassoUtenteModificato(request):
    userid = request.user
    if not userid.is_anonymous():
        if request.method == 'POST':
            if float(request.POST.get('inputValoreTasso')) <= 0:
                return HttpResponseRedirect('/tassicambio/')
            else:
                idTassoCambioSelezionato = request.POST.get('selezioneTasso')
                nuovoValoreTassoCambio = request.POST.get('inputValoreTasso')
                tassoInModifica = TassoDiCambio.objects.get(id=idTassoCambioSelezionato)
                tassoInModifica.tasso = nuovoValoreTassoCambio
                tassoInModifica.save()
        return HttpResponseRedirect('/tassicambio/')
    else:
        return HttpResponseRedirect('/login')

'''
Definizione della funzione che permette all'utente di selezionare la valuta preferita con cui visualizzare il totale nella sua Homepage
- Verifico che l'utente sia loggato con la condizione: if not userid.is_anonymous():
- Altrimenti reindirizzo l'utente alla pagina di Login
- Tramite il form ottengo la valuta selezionata dall'utente
- Assegno nel wallet Utente la nuova valuta preferita e reindirizzo alla stessa pagina per aggiornarne il contenuto
'''
def TassoUtenteSelezionato(request):
    userid = request.user
    if not userid.is_anonymous():
        if request.method == 'POST':
            idValutaSelezionata = request.POST.get('SelezionaValuta')
            valutaSelezionata = Valuta.objects.get(id=idValutaSelezionata)
            walletUtente = Wallet.objects.get(proprietario=request.user)
            walletUtente.valutaselezionata = valutaSelezionata
            walletUtente.save()
        return HttpResponseRedirect('/tassicambio/')
    else:
        return HttpResponseRedirect('/login')


'''
Definizione della funzione di Logout
- Chiamando il metodo logout effettuo il logout ed eseguo una redirect alla pagina di login
'''
def Logout(request):
    logout(request)
    return HttpResponseRedirect('/login')


'''
Definizione della funzione di Registrazione
- Effettuo un controllo sui dati inseriti dall'utente utilizzando form.is_valid()
- Se i dati sono validi creo il nuovo utente
- Altrimenti ricarico il form di registrazione
'''
def Register(request):
    userid = request.user
    if userid.is_anonymous():
        if request.method == 'POST':
            form = RegistrationForm(request.POST)
            if form.is_valid():
                user = User.objects.create_user(username=form.cleaned_data['username'],
                                                password=form.cleaned_data['password1'], email=form.cleaned_data['email'])

                walletUtente = Wallet.objects.create(proprietario=user, valutaselezionata_id=1)

                for tmpValuta in Valuta.objects.all():
                    for tmpCripto in CriptoValuta.objects.all():
                        tassoGenerato =   TassoDiCambio.objects.create(walletUtente=walletUtente, valuta=tmpValuta, criptovaluta=tmpCripto)
                        if tassoGenerato.criptovaluta.nome == 'BitCoin' and tassoGenerato.valuta.nome == 'Euro':
                             walletUtente.tassoHomeSelezionato= tassoGenerato
                             walletUtente.save()

                return HttpResponseRedirect('/login')
            else:
                return render(request, 'register.html', {'form': form})
        form = RegistrationForm()
        return render(request, 'register.html', {'form': form})
    else:
        return HttpResponseRedirect('/home')



