# -*- coding: utf-8 -*-


from __future__ import unicode_literals
from django.test import TestCase
from django.test import Client
from Crypto_ISW.form import LoginForm,RegistrationForm,AggiuntaCriptoValutaForm,ModificaTassoCambioForm,\
    AggiuntiTransazioneForm
from Crypto_ISW.models import *

# Creo la classe di test per le Valute
class Valuta_Test(TestCase):
    def setUp(self):
        #Creo le valute e prendo il numero di elementi presenti del db
        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        self.num_presenze = Valuta.objects.all().count()
    #Dovrebbe funzionare
    def test_unit_num_presenze(self):
        self.assertEquals(self.num_presenze, 3)
    #Dovrebbe fallire
    def test_unit_num_presenze_errata(self):
        self.assertNotEqual(self.num_presenze, 4)

    # Dovrebbe fallire
    def test_unit_num_presenze_errata_2(self):
        self.assertNotEqual(self.num_presenze, 0)
# Creo la classe di test per le criptovalute
class CriptoValuta_Test(TestCase):
    def setUp(self):
        #Creo le criptovalute e prendo il numero di elementi presenti del db
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')
        self.num_presenze = CriptoValuta.objects.all().count()
    #Dovrebbe funzionare
    def test_unit_num_presenze(self):
        self.assertEquals(self.num_presenze, 5)

# Creo la classe di test per le criptovalute
class Wallet_Test(TestCase):
    def setUp(self):
        # Creo le criptovalute e le valute
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        #Registro un'utente
        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        #Richiamo la vista per registrare l'utente e creare il wallet
        self.client.post('/register/', datiRegistrazione)
        self.utente = User.objects.get(username='foo')
    #Dovrebbe funzionare
    def test_unit_controllo_num_presenze(self):
        wallet = Wallet.objects.all().count()
        self.assertEquals(wallet,1)
    #Dovrebber funzionare
    def test_unit_wallet(self):
        wallet = Wallet.objects.get(id = 1)
        self.assertEquals(wallet.proprietario ,self.utente)
# Creo la classe di test per le disponibilità
class Disponibilita_Test(TestCase):

    def setUp(self):
        # Creo le criptovalute e le valute
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        # Registro un'utente
        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}
        # Richiamo la vista per registrare l'utente e creare il wallet
        self.client.post('/register/', datiRegistrazione)
        #Loggo l'utente
        self.response = self.c.post('/login/', self.credentials, follow=True)
        self.user = self.response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)
        #Uso la vista per creare la disponibilità
        self.criptovalutaDaAggiungere = {'selezioneCriptoValute': 'XRP', 'quantita': 25}
        self.c.post('/modificacriptovalute/', self.criptovalutaDaAggiungere, follow=True)
    #Dovrebbe funzionare
    def test_disponibilita_presenza(self):

        disponibilita = Disponibilita.objects.all().count()
        self.assertEquals(disponibilita,1)
    #Dovrebbe funzionare
    def test_disponibilita_proprietario(self):
        disponibilita = Disponibilita.objects.all()
        self.assertEquals(disponibilita[0].wallet.proprietario,self.user)

    # Dovrebbe funzionare
    def test_disponibilita_valore(self):
        disponibilita = Disponibilita.objects.all()
        self.assertEquals(disponibilita[0].valore, 25)

    # Dovrebbe funzionare
    def test_disponibilita_codice_criptovaluta(self):
        disponibilita = Disponibilita.objects.all()
        criptovaluta = CriptoValuta.objects.get(codice='XRP')
        self.assertEquals(disponibilita[0].criptovaluta,criptovaluta)

# Creo la classe di test per il Tasso di cambio
class Tassodicambio_Test(TestCase):

    def setUp(self):
        # Creo le criptovalute e le valute
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        # Registro un'utente
        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        # Richiamo la vista per registrare l'utente e creare il wallet
        self.response = self.c.post('/register/', datiRegistrazione)
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}
        # Loggo l'utente
        response = self.c.post('/login/', self.credentials, follow=True)
        self.user = response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)
        self.tassiUtente = TassoDiCambio.objects.filter(walletUtente=self.walletUtente)
        self.idvalute = []
        self.idtassi = []
        #Creo la lista con i tassi dell'utente
        for tmpTasso in self.tassiUtente:
            self.idtassi.append(tmpTasso.id)
            self.idvalute.append(tmpTasso.valuta.id)

    #Dovrebbe funzionare
    def test_controllo_cambio_e_proprietario(self):
        tasso = TassoDiCambio.objects.get(id=self.idtassi.__getitem__(0))
        self.assertEqual(tasso.walletUtente.proprietario,self.user)
        self.assertEqual(tasso.tasso, 1.0)



# Creo la classe di test per le transazione
class Transaction_Test(TestCase):
    def setUp(self):
        # Creo le criptovalute e le valute
        self.c = Client()

        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        # Registro un'utente
        datiRegistrazione = {'username': 'alice',
                             'email': 'foo1@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        datiLogin = {'username': 'alice',
                     'password': 'a1234567'}
        # Richiamo la vista per registrare l'utente e creare il wallet
        self.client.post('/register/', datiRegistrazione)
        # Loggo l'utente
        response = self.c.post('/login/', datiLogin, follow=True)
        self.user1 = response.context['user']
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': 1000}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)

        # Creo un secondo utente
        datiRegistrazione2 = {'username': 'foo2',
                              'email': 'foo@example.com',
                              'password1': 'foo123456',
                              'password2': 'foo123456'}
        self.c2 = Client()
        #Uso la vista per registrare il secondo utente
        self.response2 = self.c2.post('/register/', datiRegistrazione2)
        self.credentials2 = {
            'username': 'foo2',
            'password': 'foo123456'}
        self.response2 = self.c2.post('/login/', self.credentials2, follow=True)
        self.user2 = self.response2.context['user']
        self.walletUser2 = Wallet.objects.get(proprietario=self.user2)
    #Dovrebbe funzionare
    def test_unit_transazione_corretta(self):
        datiTransazione = {'selezionawallet': self.walletUser2.id,
                           'criptovaluta': 'BTC',
                           'quantita': 22.90}
        self.c.post('/transazioni/', datiTransazione, follow=True)
        self.assertEquals(Transazione.objects.filter(mittente=User.objects.get(username=self.user1).id,
                                                   destinatario=User.objects.get(username=self.user2).id,
                                                   quantita=22.90).count(), 1)
# Creo la classe di test per il form del Login
class LoginForm_Test(TestCase):

    #Dovrebbe fallire
    def test_username_vuoto(self):
        dati = {
            'username': '',
            'password': 'a1234567'}
        form = LoginForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_username_password_vuota(self):
        dati = {
            'username': '',
            'password': ''}
        form = LoginForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password_vuota(self):
        dati = {
            'username': 'alice',
            'password': ''}
        form = LoginForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe funzionare
    def test_dati_corretti(self):
        dati = {
            'username': 'alice',
            'password': 'a1234567'}
        form = LoginForm(dati)
        self.assertTrue(form.is_valid())
# Creo la classe di test per il form delle registrazioni
class RegistrationForm_Test(TestCase):
    #Dovrebbe fallire
    def test_campi_vuoti(self):
        dati = {
            'username':'',
            'email': '',
            'password1': '',
            'password2': '' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_username_vuoto(self):
        dati = {
            'username':'',
            'email': 'unica@unica.it',
            'password1': 'a1234567',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password_vuoto(self):
        dati = {
            'username':'unica',
            'email': 'unica@unica.it',
            'password1': '',
            'password2': '' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password1_vuoto(self):
        dati = {
            'username':'unica',
            'email': 'unica@unica.it',
            'password1': '',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password2_vuoto(self):
        dati = {
            'username':'unica',
            'email': 'unica@unica.it',
            'password1': 'a1234567',
            'password2': '' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_email_vuoto(self):
        dati = {
            'username':'unica',
            'email': '',
            'password1': 'a1234567',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_email_simbolo_mancante(self):
        dati = {
            'username':'unica',
            'email': 'unica.it',
            'password1': 'a1234567',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password_diverse(self):
        dati = {
            'username':'unica',
            'email': 'unica.it',
            'password1': 'a12345678',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_password_meno_caratteri(self):
        dati = {
            'username':'unica',
            'email': 'unica.it',
            'password1': 'a123456',
            'password2': 'a123456' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_simbolo_non_corretto_username(self):
        dati = {
            'username':'@',
            'email': 'unica@unica.it',
            'password1': 'a123456',
            'password2': 'a123456' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_simbolo_doppio_email(self):
        dati = {
            'username':'alice',
            'email': 'unica@@unica.it',
            'password1': 'a1234567',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe funzionare
    def test_corretto(self):
        dati = {
            'username':'unica',
            'email': 'unica@unica.it',
            'password1': 'a1234567',
            'password2': 'a1234567' }
        form = RegistrationForm(dati)
        self.assertTrue(form.is_valid())

# Creo la classe di test per il form delle AggiungiCriptoValute
class AggiungiCriptoValuteForm_Test(TestCase):

    def setUp(self):
        # Creo le criptovalute
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')


    #Dovrebbe funzionare
    def test_selezione_corretta(self):
        dati ={
            'selezioneCriptoValute': 'BTC',
            'quantita' : '50'
        }
        form = AggiuntaCriptoValutaForm(dati)
        self.assertTrue(form.is_valid())
    #Dovrebbe fallire
    def test_selezione_sbagliata(self):
        dati ={
            'selezioneCriptoValute': 'CCN',
            'quantita' : '50'
        }
        form = AggiuntaCriptoValutaForm(dati)
        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_quantita_negativa(self):
        dati ={
            'selezioneCriptoValute': 'BTC',
            'quantita' : '-50'
        }
        form = AggiuntaCriptoValutaForm(dati)
        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_quantita_negativa_selezione_sbagliata(self):
        dati ={
            'selezioneCriptoValute': 'CCN',
            'quantita' : '-50'
        }
        form = AggiuntaCriptoValutaForm(dati)
        self.assertFalse(form.is_valid())

    # Dovrebbe fallire
    def test_quantita_letterale(self):
        dati ={
            'selezioneCriptoValute': 'BTC',
            'quantita' : 'ciao'
        }
        form = AggiuntaCriptoValutaForm(dati)
        self.assertFalse(form.is_valid())


# Creo la classe di test per il form delle ModificaTassodiCambioForm
class ModificaTassodiCambioForm_Test(TestCase):
    def setUp(self):
        # Creo le criptovalute e le valute
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        #Registro un'utente
        datiRegistrazione = {'username': 'alice',
                             'email': 'foo1@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        datiLogin = {'username': 'alice',
                     'password': 'a1234567'}
        #Registro un secondo utente
        datiRegistrazione2 = {'username': 'franku',
                             'email': 'foo@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.client.post('/register/', datiRegistrazione)
        self.client.post('/register/', datiRegistrazione2)
        self.user = User.objects.get(username='alice')
        self.user2 = User.objects.get(username='franku')
        self.wallet1 = Wallet.objects.get(proprietario=self.user)
        self.tassi= []
        self.tassi =TassoDiCambio.objects.filter(walletUtente=self.wallet1)
    #Dovrebbe funzionare
    def test_cambio_tasso_corretto(self):
        dati = {
            'selezioneTasso': self.tassi[0].id,
            'inputValoreTasso': '12'
        }
        form = ModificaTassoCambioForm(dati,user=self.user)

        self.assertTrue(form.is_valid())
    #Dovrebbe fallire
    def test_selezione_errata_1(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': tassouser2[0].id,
            'inputValoreTasso': '12'
        }
        form = ModificaTassoCambioForm(dati, user=self.user)

        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_selezione_errata_2(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': '',
            'inputValoreTasso': '12'
        }
        form = ModificaTassoCambioForm(dati, user=self.user)

        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_selezione_errata_3(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': 'Bitcoin-Euro',
            'inputValoreTasso': '12'
        }
        form = ModificaTassoCambioForm(dati, user=self.user)

        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_quantita_vuota(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': self.tassi[0].id,
            'inputValoreTasso': ''
        }
        form = ModificaTassoCambioForm(dati, user=self.user)

        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_quantita_errata(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': self.tassi[0].id,
            'inputValoreTasso': '-50'
        }
        form = ModificaTassoCambioForm(dati, user=self.user)

        self.assertFalse(form.is_valid())
    #Dovrebbe fallire
    def test_quantita_letterale(self):
        wallet = Wallet.objects.get(proprietario=self.user2)
        tassouser2 = TassoDiCambio.objects.filter(walletUtente=wallet)

        dati = {
            'selezioneTasso': self.tassi[0].id,
            'inputValoreTasso': 'cinquanta'
        }
        form = ModificaTassoCambioForm(dati, user=self.user)
        self.assertFalse(form.is_valid())


# Creo la classe di test per il form delle AggiuntiTransazioneForm
class AggiuntiTransazioneForm_Test(TestCase):

        def setUp(self):
            # Creo le criptovalute e le valute
            self.c = Client()
            CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
            CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
            CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
            CriptoValuta.objects.create(nome='Ripple', codice='XRP')
            CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

            Valuta.objects.create(nome='Dollari', simbolo='$')
            Valuta.objects.create(nome='Euro', simbolo='€')
            Valuta.objects.create(nome='Sterline', simbolo='£')
            #Registro un'utente
            datiRegistrazione = {'username': 'alice',
                                 'email': 'foo1@example.com',
                                 'password1': 'a1234567',
                                 'password2': 'a1234567'}
            datiLogin = {'username': 'alice',
                         'password': 'a1234567'}
            #Registro un secondo utente
            datiRegistrazione2 = {'username': 'franku',
                                  'email': 'foo@example.com',
                                  'password1': 'a1234567',
                                  'password2': 'a1234567'}
            self.client.post('/register/', datiRegistrazione)
            self.client.post('/register/', datiRegistrazione2)
            #Uso la vista per loggare l'utente
            self.credentials={
                'username':'alice',
                'password':'a1234567'
            }
            self.c.post('/login/', self.credentials, follow=True)
            self.user = User.objects.get(username='alice')
            self.user2 = User.objects.get(username='franku')
            self.wallet1 = Wallet.objects.get(proprietario=self.user)
            self.wallet2 = Wallet.objects.get(proprietario=self.user2)
            self.cripto = CriptoValuta.objects.get(nome='BitCoin')
            self.disponibilita = Disponibilita.objects.create(valore=100,wallet=self.wallet1,criptovaluta=self.cripto)
        #Dovrebbe funzionare
        def test_transazione_corretta(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta':'BTC',
                'quantita':50
            }
            form = AggiuntiTransazioneForm(dati,user=self.user)
            self.assertTrue(form.is_valid())
        #Dovrebbe fallire
        def test_valuta_errata_1(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': 'ETH',
                'quantita': 50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_valuta_errata_2(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': 'CNN',
                'quantita': 50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_valuta_errata_3(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': '0',
                'quantita': 50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_quantita_errata_1(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': 'BTC',
                'quantita': -50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_quantita_errata_2(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': 'BTC',
                'quantita': ''
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_quantita_errata_2(self):
            dati = {
                'selezionawallet': self.user2.id,
                'criptovaluta': 'BTC',
                'quantita': 'cinquanta'
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_wallet_errato_1(self):
            dati = {
                'selezionawallet': '',
                'criptovaluta': 'BTC',
                'quantita': 50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

        # Dovrebbe fallire
        def test_wallet_errato_2(self):
            dati = {
                'selezionawallet': 'franku',
                'criptovaluta': 'BTC',
                'quantita': 50
            }
            form = AggiuntiTransazioneForm(dati, user=self.user)
            self.assertFalse(form.is_valid())

