# -*- coding: utf-8 -*-


from __future__ import unicode_literals
from django.http import request
from django.shortcuts import render
from django.test import TestCase
from django.test import Client
from Crypto_ISW.models import *

'''
Creo la classe di test per il Login
- Creo un nuovo utente per poi testare il login
'''
class LoginTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        datiRegistrazione = {'username': 'luigi',
                              'email': 'foo1@example.com',
                              'password1': 'a1234567',
                              'password2': 'a1234567'}
        response = self.c.post('/register/', datiRegistrazione)

    def test_login_1(self):
        self.dati = {
            'username': 'luigi',
            'password': 'a1234567'
        }
        response = self.c.post('/login/', self.dati, follow=True)
        # Dovrebbe essere loggato
        self.assertTrue(response.context['user'].is_active)

    def test_login_2(self):
        self.datiInvalidi = {
            'username': 'paolo',
            'password': 'dekfurns'
        }
        response = self.c.post('/login/', self.datiInvalidi, follow=True)
        # Dovrebbe fallire
        self.assertFalse(response.context['user'].is_active)
        self.passInvalid = {
            'username': 'luigi',
            'password': 'a1122'
        }
        response = self.c.post('/login/', self.passInvalid, follow=True)
        # Dovrebbe fallire
        self.assertFalse(response.context['user'].is_active)
        self.passInvalid2 = {
            'username': 'giangi',
            'password': ''
        }
        response = self.c.post('/login/', self.passInvalid2, follow=True)
        # Dovrebbe fallire
        self.assertFalse(response.context['user'].is_active)

'''
Creo la classe di test per il Logout
'''
class LogoutTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        datiRegistrazione = {'username': 'luigi',
                             'email': 'foo1@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.response = self.c.post('/register/', datiRegistrazione)
        self.dati = {
            'username': 'luigi',
            'password': 'a1234567'
        }
        self.response = self.c.post('/login/', self.dati, follow=True)
        self.user = self.response.context['user']

    def test_logout_success(self):
        # Verifico che sia loggato
        self.assertContains(self.response, 'Logout')
        # Eseguo la richiesta di Logout
        self.response = self.c.post('/logout/')
        # Verifico che il redirect della risposta sia /login
        self.assertEquals(self.response.url, '/login')



''' 
Creo la classe di test per la Registrazione
- Creo un nuovo utente per verificare il corretto esposizione di errori
'''
class RegistrazioneTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        datiRegistrazione = {'username': 'alice',
                             'email': 'foo1@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        datiLogin = {'username': 'alice',
                     'password': 'a1234567'}
        self.client.post('/register/', datiRegistrazione)
        response = self.c.post('/login/', datiLogin, follow=True)
        self.sample_user = response.context['user']

    def test_new_user_is_active(self):
        self.failUnless(
            self.sample_user.is_active)  # Controllo che il nuovo utente non sia attivo dopo la registrazione

    def test_registrazione_success(self):
        datiRegistrazione = {'username': 'marco',
                             'email': 'marco@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.response = self.client.post('/register/', datiRegistrazione)
        #Controllo che l'utente venga reindirizzato al Login dopo la registrazione
        self.assertEqual(self.response.url, '/login')

    def test_registrazione_password_diverse(self):
        #Dati di registrazione errati
        datiRegistrazione = {'username': 'marco',
                             'email': 'marco@example.com',
                             'password1': 'a1234567',
                             'password2': 'b4567890'}
        self.response = self.client.post('/register/', datiRegistrazione)
        # Controllo che all'utente venga mostrato l'errore
        self.assertContains(self.response, 'Le password inserite sono diverse.')

    def test_registrazione_username_non_valido(self):
        #Dati di registrazione errati
        datiRegistrazione = {'username': 'ali/*ce',
                             'email': 'marco@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.response = self.client.post('/register/', datiRegistrazione)
        #Controllo che all'utente venga mostrato l'errore
        self.assertContains(self.response, 'L username puo contenere solo caratteri alfanumerici e underscore')

    def test_registrazione_username_esistente(self):
        #Dati di registrazione errati
        datiRegistrazione = {'username': 'alice',
                             'email': 'marco@example.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.response = self.client.post('/register/', datiRegistrazione)
        #Controllo che all'utente venga mostrato l'errore
        self.assertContains(self.response, 'Username gia esistente.')

    def test_registrazione_email_non_valida(self):
        #Dati di registrazione errati
        datiRegistrazione = {'username': 'elisabetta',
                             'email': 'elisabettaexample.com',
                             'password1': 'a1234567',
                             'password2': 'a1234567'}
        self.response = self.client.post('/register/', datiRegistrazione)
        #Controllo che all'utente venga mostrato l'errore
        self.assertContains(self.response, 'Email non valida.')

    def test_registrazione_errori_multipli(self):
        #Dati di registrazione errati
        datiRegistrazione = {'username': 'elisa/betta',
                             'email': 'elisabettaexample.com',
                             'password1': 'a1234567',
                             'password2': 'a12345678'}
        self.response = self.client.post('/register/', datiRegistrazione)
        # Controllo che all'utente vengano mostrati gli errori
        self.assertContains(self.response, 'L username puo contenere solo caratteri alfanumerici e underscore')
        self.assertContains(self.response, 'Email non valida.')
        self.assertContains(self.response, 'Le password inserite sono diverse.')


'''
Creo la classe di test per l'inserimento di una CriptoValuta
'''
class AggiungiCriptoTest(TestCase):
    def setUp(self):
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')

        self.c = Client()
        datiRegistrazione={'username': 'foo',
                                       'email': 'foo@example.com',
                                       'password1': 'foo123456',
                                       'password2': 'foo123456'}
        self.response = self.c.post('/register/', datiRegistrazione)

        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        self.response = self.c.post('/login/', self.credentials, follow=True)
        self.user = self.response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)



    # Verifico l'aggiunta di una nuova CriptoValuta nel Wallet di un utente
    def test_aggiungi_criptovaluta_1(self):
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': 10}
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)

        # Controllo la disponibilirà attuale

        self.assertContains(self.response, "BitCoin")
        self.assertContains(self.response, "10.0")


    # Verifico l'aggiunta di disponibilita di una CriptoValuta in un wallet in cui è gia presente disponibilità della stessa
    def test_aggiungi_criptovaluta_2(self):
        criptovalutaDaAggiungere1 = {'selezioneCriptoValute': 'XRP', 'quantita': 25}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere1, follow=True)

        criptovalutaDaAggiungere2 = {'selezioneCriptoValute': 'XRP', 'quantita': 30}
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere2, follow=True)

        self.assertContains(self.response, "Ripple")
        self.assertContains(self.response, "55.0")

    # Verifico se aggiungendo una criptovaluta con quantita' uguale a 0 venga mostrato un errore
    def test_aggiungi_criptovaluta_errore(self):
        criptovalutaDaAggiungere1 = {'selezioneCriptoValute': 'XRP', 'quantita': 0}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere1, follow=True)
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere1, follow=True)
        self.assertNotContains(self.response, 'Il valore deve essere superiore o uguale a 0,001.')

    # Verifico se aggiungendo una criptovaluta con quantita' minore di 0 venga mostrato un errore
    def test_aggiungi_criptovaluta_errore_2(self):
        criptovalutaDaAggiungere1 = {'selezioneCriptoValute': 'XRP', 'quantita': -10}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere1, follow=True)
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere1, follow=True)
        self.assertNotContains(self.response, 'Il valore deve essere superiore o uguale a 0,001.')


'''
Creo la classe di test per la rimozione di CriptoValute
'''
class RimuoviCriptoTest(TestCase):
    def setUp(self):
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Dollari', simbolo='$')
        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Sterline', simbolo='£')
        self.c = Client()
        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        response = self.c.post('/register/', datiRegistrazione)


        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        response = self.c.post('/login/', self.credentials, follow=True)
        self.user = response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': '10'}
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'ETH', 'quantita': '22'}
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)



    def test_rimuovi_criptovaluta_1(self):
        #Scelgo la CriptoValuta da rimuovere
        datiEliminazione = {'eliminaDisponibilitaCriptovaluta': str(CriptoValuta.objects.get(codice='BTC').id)}
        self.response = self.c.post('/rimuovi/', datiEliminazione, follow=True)

        #Verifico che nella risposta non ci sia la CriptoValuta rimossa
        self.assertNotContains(self.response, "BitCoin 10.0")

    def test_rimuovi_criptovaluta_2(self):
        #Scelgo la CriptoValuta da rimuovere
        datiEliminazione = {'eliminaDisponibilitaCriptovaluta': str(CriptoValuta.objects.get(codice='ETH').id)}
        self.response = self.c.post('/rimuovi/', datiEliminazione, follow=True)

        #Verifico che nella risposta non ci sia la CriptoValuta rimossa
        self.assertNotContains(self.response, "Ethereum 22.0")


'''
Creo la classe di test per la gestione dei Tassi di Cambio
'''
class ModificaTassoTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')

        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.response = self.c.post('/register/', datiRegistrazione)
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        response = self.c.post('/login/', self.credentials, follow=True)
        self.user = response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)
        self.tassiUtente = TassoDiCambio.objects.filter(walletUtente=self.walletUtente)
        self.idvalute = []
        self.idtassi = []
        for tmpTasso in self.tassiUtente:
            self.idtassi.append(tmpTasso.id)
            self.idvalute.append(tmpTasso.valuta.id)

    def test_cambia_tasso_1(self):
        datiCambio = {'selezioneTasso': self.idtassi.__getitem__(0),
                      'inputValoreTasso': 12.0}
        self.response = self.c.post('/tassoModificato/', datiCambio, follow=True)
        #Verifico che il tasso presente nei tassiUtente sia presente nella pagina tassi di cambio
        self.assertContains(self.response, self.tassiUtente.get(id=self.idtassi.__getitem__(0)).tasso)

    def test_cambia_tasso_2(self):
        datiCambio = {'selezioneTasso': self.idtassi.__getitem__(2),
                      'inputValoreTasso': 44.0}
        self.response = self.c.post('/tassoModificato/', datiCambio, follow=True)
        #Verifico che il tasso presente nei tassiUtente sia presente nella pagina tassi di cambio
        self.assertContains(self.response, self.tassiUtente.get(id=self.idtassi.__getitem__(2)).tasso)

    def test_cambia_tasso_non_valido(self):
        datiCambio = {'selezioneTasso': self.idtassi.__getitem__(2),
                      'inputValoreTasso': -44.0}
        self.response = self.c.post('/tassoModificato/', datiCambio, follow=True)
        #Verifico che il tasso presente nei tassiUtente sia presente nella pagina tassi di cambio
        self.assertNotContains(self.response, '-44.0')


'''
Creo la classe di test per la selezione della Valuta preferita
'''
class SelezionaValutaTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')

        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.response = self.c.post('/register/', datiRegistrazione)
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        self.response = self.c.post('/login/', self.credentials, follow=True)
        self.user = self.response.context['user']
        self.walletUtente = Wallet.objects.get(proprietario=self.user)
        self.tassiUtente = TassoDiCambio.objects.filter(walletUtente=self.walletUtente)
        self.idvalute = []
        self.idtassi = []
        for tmpTasso in self.tassiUtente:
            self.idtassi.append(tmpTasso.id)
            self.idvalute.append(tmpTasso.valuta.id)

        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': 10}
        self.response = self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)

    def test_seleziona_valuta(self):
        walletUtente = Wallet.objects.get(proprietario=self.user)
        datiSelezione = {'SelezionaValuta': self.idvalute.__getitem__(1)}
        self.response = self.c.post('/tassoUtenteSelezionato/', datiSelezione, follow=True)

        disponibilitaSelezionataUtente = []
        disponibilitaSelezionataUtente = Disponibilita.objects.filter(wallet=walletUtente)
        cont = 0
        for x in disponibilitaSelezionataUtente:
            supporto = TassoDiCambio.objects.get(criptovaluta=x.criptovaluta, valuta=walletUtente.valutaselezionata,
                                                 walletUtente=walletUtente)
            cont = cont + x.valore * supporto.tasso
        cont = str(cont) + " " + walletUtente.valutaselezionata.simbolo
        listaDisponibilitaUtente = Disponibilita.objects.filter(wallet=walletUtente)
        response = render(request, 'home.html', {'listaDisponibilitaUtente': listaDisponibilitaUtente,
                                                     'disponibilitaSelezionataUtente': cont})
        #Verifico che la Valuta selezionata dall'utente sia visualizzata nella home
        self.assertContains(response, Wallet.objects.get(proprietario=self.user).valutaselezionata.simbolo)

'''
Creo la classe di test per la creazione di una nuova transazione
'''
class CreaTransazioneTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')

        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.response1 = self.c.post('/register/', datiRegistrazione)
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        self.response1 = self.c.post('/login/', self.credentials, follow=True)
        self.user1 = self.response1.context['user']
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': 10}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)

        # Creo un secondo utente
        datiRegistrazione2 = {'username': 'foo2',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.c2 = Client()
        self.response2 = self.c2.post('/register/', datiRegistrazione2)
        self.credentials2 = {
            'username': 'foo2',
            'password': 'foo123456'}
        self.response2 = self.c2.post('/login/', self.credentials2, follow=True)
        self.user2 = self.response2.context['user']
        self.walletUser2 = Wallet.objects.get(proprietario=self.user2)

    def test_add_transazione_success(self):
        datiTransazione = {'selezionawallet': self.walletUser2.id,
                           'criptovaluta': 'BTC',
                           'quantita': 1.234}
        self.response1 = self.c.post('/transazioni/', datiTransazione, follow=True)
        self.transazione = Transazione.objects.get(mittente=User.objects.get(username=self.user1).id,
                                                   destinatario=User.objects.get(username=self.user2).id,
                                                   quantita=1.234).idtransazione
        # Verifico che nella pagina venga mostrata la nuova transazione verificando la presenza del codice di transazione
        self.assertContains(self.response1, self.transazione)

    def test_add_transazione_fail(self):
        datiTransazione = {'selezionawallet': self.walletUser2.id,
                           'criptovaluta': 'BTC',
                           'quantita': 12}
        self.response1 = self.c.post('/transazioni/', datiTransazione, follow=True)
        #Verifico che nella pagina venga visualizzato un errore in quanto l'importo inserito e' superiore alle disponibilita'
        self.assertContains(self.response1, 'Importo inserito superiore alla disponibilità corrente')


'''
Creo la classe di test per la visualizzazione dei dettagli di una transazione
'''
class DettaglioTransazioneTest(TestCase):
    def setUp(self):
        self.c = Client()
        CriptoValuta.objects.create(nome='BitCoin', codice='BTC')
        CriptoValuta.objects.create(nome='Ethereum', codice='ETH')
        CriptoValuta.objects.create(nome='Ripple', codice='XRP')
        CriptoValuta.objects.create(nome='Litecoin', codice='LTC')
        CriptoValuta.objects.create(nome='Primecoin', codice='PPC')

        Valuta.objects.create(nome='Euro', simbolo='€')
        Valuta.objects.create(nome='Dollaro', simbolo='$')
        Valuta.objects.create(nome='Sterline', simbolo='£')

        datiRegistrazione = {'username': 'foo',
                             'email': 'foo@example.com',
                             'password1': 'foo123456',
                             'password2': 'foo123456'}
        self.response1 = self.c.post('/register/', datiRegistrazione)
        self.credentials = {
            'username': 'foo',
            'password': 'foo123456'}

        self.response1 = self.c.post('/login/', self.credentials, follow=True)
        self.user1 = self.response1.context['user']
        criptovalutaDaAggiungere = {'selezioneCriptoValute': 'BTC', 'quantita': 10}
        self.c.post('/modificacriptovalute/', criptovalutaDaAggiungere, follow=True)

        # Creo un secondo utente
        datiRegistrazione2 = {'username': 'foo2',
                              'email': 'foo@example.com',
                              'password1': 'foo123456',
                              'password2': 'foo123456'}
        self.c2 = Client()
        self.response2 = self.c2.post('/register/', datiRegistrazione2)
        self.credentials2 = {
            'username': 'foo2',
            'password': 'foo123456'}
        self.response2 = self.c2.post('/login/', self.credentials2, follow=True)
        self.user2 = self.response2.context['user']
        self.walletUser2 = Wallet.objects.get(proprietario=self.user2)
        datiTransazione = {'selezionawallet': self.walletUser2.id,
                           'criptovaluta': 'BTC',
                           'quantita': 1.234}
        self.response1 = self.c.post('/transazioni/', datiTransazione, follow=True)
        self.id = Transazione.objects.get(mittente=User.objects.get(username=self.user1).id,
                                                     destinatario=User.objects.get(username=self.user2).id,
                                                     quantita=1.234).id
        self.idtransazione = Transazione.objects.get(mittente=User.objects.get(username=self.user1).id,
                                                   destinatario=User.objects.get(username=self.user2).id,
                                                   quantita=1.234).idtransazione

        # Creo un terzo utente
        datiRegistrazione3 = {'username': 'foo3',
                              'email': 'foo@example.com',
                              'password1': 'foo123456',
                              'password2': 'foo123456'}
        self.c3 = Client()
        self.response3 = self.c3.post('/register/', datiRegistrazione3)
        self.credentials3 = {
            'username': 'foo3',
            'password': 'foo123456'}
        self.response3 = self.c3.post('/login/', self.credentials3, follow=True)
        self.user3 = self.response3.context['user']


    def test_opened_transactions_success(self):
        datiDettaglio = {'id': self.id}
        self.response = self.c.get('/dettagliotransazione/', datiDettaglio, follow=True)
        #Verifico che la visualizzazione dei dettagli della transazione sia avvenuta con successo
        # verificando la presenza del codice di transazione nella pagina
        self.assertContains(self.response, str(self.idtransazione))

    def test_opened_transactions_fail(self):
        datiDettaglio = {'id': self.id}
        self.response3 = self.c3.get('/dettagliotransazione/', datiDettaglio, follow=True)
        #Verifico che la visualizzazione dei dettagli della transazione sia fallita
        #Poiche' l'utente non essendo ne mittente ne destinatario non e' autorizzato a visualizzarla
        self.assertNotContains(self.response3, str(self.idtransazione))






